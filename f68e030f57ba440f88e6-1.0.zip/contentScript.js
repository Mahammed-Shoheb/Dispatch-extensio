
const data = {
  customerNumber: "",
  cpr: "",
  installAddress1: "",
  installCity: "",
  installZipCode: "",
  contactName: "",
  contactNumber: "",
  officHours: "",
  scopeOfWork: "",
  internalTicketNumber: "",
  customerSiteName: "",
  date: "",
  time: ""
}

// Copy the data from the local dispatch form webpage 

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action == "copyData") {
    extractData();
  }
})

function extractData() {
  for (const key in data) {
    if (key != "scopeOfWork") {
      data[key] = document.getElementById(key).value.trim();
    }
  }

  data["scopeOfWork"] = document.getElementById("formOutput").innerText.trim()
  chrome.storage.local.set({ "copiedData": data });
}

function updateElement(key, copiedData) {
  document.querySelector(`[formControlName="${key}"]`).value = copiedData[key]
  document.querySelector(`[formControlName="${key}"]`).dispatchEvent(new Event("input", { bubbles: true }))
  document.querySelector(`[formControlName="${key}"]`).dispatchEvent(new Event("change", { bubbles: true }))
  document.querySelector(`[formControlName="${key}"]`).dispatchEvent(new Event("keydown", { bubbles: true }))
  document.querySelector(`[formControlName="${key}"]`).dispatchEvent(new Event("keyup", { bubbles: true }))
}


// Paste the date into the BSET form fields 

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action == "pasteData") {

    updateData();
  }
})

async function updateData() {
  const { copiedData } = await chrome.storage.local.get("copiedData")

  const customerNumberInputEle = document.querySelector(`[formControlName="customerNumber"]`)
  if (customerNumberInputEle) {
    customerNumberInputEle.value = copiedData["customerNumber"]
    customerNumberInputEle.dispatchEvent(new Event("input", { bubbles: true }));
  }
  const repairRadioEle = document.getElementsByClassName("mat-radio-input")[0]
  repairRadioEle.checked = true
  repairRadioEle.dispatchEvent(new Event("change", { bubbles: true }))

  updateElement("scopeOfWork", copiedData)

  for (key in copiedData) {
    if (document.querySelector(`[formControlName="${key}"]`) && key != "scopeOfWork") {
      updateElement(key, copiedData)
    }
  }


}




