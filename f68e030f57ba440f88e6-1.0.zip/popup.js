console.log("popup.js");
document.getElementById("copyBtn").addEventListener("click", () => {
    console.log("copy btn");
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "copyData" })
    })
})

document.getElementById("pasteBtn").addEventListener("click", () => {
    console.log("paste btn");
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "pasteData" })
    })
})